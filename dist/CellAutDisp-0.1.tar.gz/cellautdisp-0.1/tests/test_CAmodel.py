# Create a tests directory and write unit tests for your code. 
# Use a testing framework like pytest or the built-in unittest module.